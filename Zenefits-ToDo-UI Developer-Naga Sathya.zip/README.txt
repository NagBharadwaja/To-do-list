Skills used: In this todo application, the skills I have used HTML5, CSS3, jquery, media queries (for responsive web design).

Tools used: The tools I used are Sublime editor and Google Developer Console to screen cast with the phone, tablet mode and 
			Adobe Photoshop CC 2015 for the logo design.

Application Info:			
This app "JUST DO IT" allows the user to create, view and edit the tasks. 

CREATE: The user will be able to create tasks by the click or tap on mouse 
		or touch pad	pressing enter key (in case of desktops and laptops).
EDIT: 	The user will be able to edit by tapping or clicking on one of the
		items in the list which I made to be editable. 
		After editing the task the user can tap or click anywhere to confirm
		that he/she has edited the task.
VIEW:	The user will be able to view the data even after reloading the page or
		reopening the browser once it is closed, as the data is stored using the
		localStorage object which persists in the browser from one week to one year.

The application is tested in the Google Chrome's Google Developer Console in the device mode.